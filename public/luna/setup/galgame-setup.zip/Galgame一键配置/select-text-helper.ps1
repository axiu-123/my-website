﻿<#
.SYNOPSIS
    首次"选择文本"助手：读游戏画面台词 -> 填进 LunaTranslator 选择窗口搜索框 -> 候选行自动过滤到1行。
.DESCRIPTION
    只在"首次选文本"时用一次。不是自动点击 Qt 控件（脆弱），而是用 LT 自带的搜索框：
    搜索框过滤的是每条 hook 抓到的历史文本，填入台词里的独特汉字后，
    只有真正抓到这句台词的那一行会保持可见，人工点一下即可。
    截图/OCR 全部走 LT 本机 127.0.0.1 网络服务，不额外出网。
.PARAMETER DryRun
    只演示流程，不截图、不按键。
#>
param([switch]$DryRun)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

function Log([string]$m)     { Write-Host ('[选文本助手] ' + $m) }
function LogOk([string]$m)   { Write-Host ('[选文本助手] ' + $m) -ForegroundColor Green }
function LogWarn([string]$m) { Write-Host ('[选文本助手] ' + $m) -ForegroundColor Yellow }
function LogErr([string]$m)  { Write-Host ('[选文本助手] ' + $m) -ForegroundColor Red }

Log '=== 首次选文本助手 ==='

# ---------- 1. 找 LunaTranslator 与网络服务端口 ----------
$port = 2333
try {
    $cfgPath = 'D:\LunaTranslator_x64\userconfig\config.json'
    if (Test-Path -LiteralPath $cfgPath) {
        $j = (Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8) | ConvertFrom-Json
        if ($j.networktcpport) { $port = [int]$j.networktcpport }
    }
} catch {}

$base = "http://127.0.0.1:$port"

# 检查网络服务（/api/ocr 依赖它）
$svcOk = $false
try {
    $r = Invoke-WebRequest -Uri ($base + '/') -TimeoutSec 3 -UseBasicParsing
    if ($r.StatusCode -eq 200) { $svcOk = $true }
} catch {}
if (-not $svcOk) {
    LogErr "LunaTranslator 网络服务未响应（端口 $port）。"
    Log '请先运行「一键玩Galgame.bat」或「一键开启Luna网络服务.bat」，再运行本助手。'
    if (-not $DryRun) { Read-Host '按回车退出' | Out-Null }
    exit 1
}
LogOk "网络服务就绪（端口 $port）。"

# ---------- 2. 找"选择文本"窗口 ----------
function Find-SelectWindow {
    $found = $null
    Get-Process | Where-Object { $_.MainWindowTitle -and $_.MainWindowTitle -like '*选择文本*' } | ForEach-Object {
        $found = $_
    }
    return $found
}

$selWin = Find-SelectWindow
if (-not $selWin) {
    LogWarn '没找到"选择文本"窗口。'
    Log '正确顺序：先运行「一键玩Galgame.bat」打开游戏 -> 让游戏显示两三句对话 -> 选择窗口会自动弹出 -> 再运行本助手。'
    if (-not $DryRun) { Read-Host '按回车退出' | Out-Null }
    exit 2
}
LogOk ('已找到选择文本窗口：' + $selWin.MainWindowTitle)

# ---------- 3. 截游戏画面（排除选择窗口自身）-> OCR 读台词 ----------
function Get-ScreenShot {
    $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $bmp = New-Object System.Drawing.Bitmap($bounds.Width, $bounds.Height)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($bounds.Left, $bounds.Top, 0, 0, $bmp.Size)
    $g.Dispose()
    return $bmp
}

function Invoke-LTOcr([System.Drawing.Bitmap]$bmp) {
    $ms = New-Object System.IO.MemoryStream
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $b64 = [Convert]::ToBase64String($ms.ToArray())
    $ms.Dispose()
    $body = @{ image = $b64 } | ConvertTo-Json -Compress
    $resp = Invoke-RestMethod -Uri ($base + '/api/ocr') -Method Post `
        -Body $body -ContentType 'application/json' -TimeoutSec 30
    return $resp
}

if ($DryRun) {
    Log '[DryRun] 将：截图 -> /api/ocr 读台词 -> 取独特汉字 -> 填入搜索框。'
    exit 0
}

Log '请在游戏里推进到有对话的一句（画面上要有清晰的日文/原文台词）。'
Read-Host '台词显示好后，按回车开始识别' | Out-Null

$bmp = Get-ScreenShot
Log '正在用 LunaTranslator 自带 OCR 识别画面台词（本机，不出网）...'
$ocr = $null
try { $ocr = Invoke-LTOcr $bmp } catch { LogErr ('OCR 失败: ' + $_.Exception.Message) }
$bmp.Dispose()

if (-not $ocr -or -not $ocr.results) {
    LogErr '没识别到文字。请把游戏对话框调到清晰，或手动把台词里的几个字填进选择窗口搜索框。'
    Read-Host '按回车退出' | Out-Null
    exit 3
}

# 拼接所有识别行，按长度排序取最有可能是台词的长句
$lines = @($ocr.results | ForEach-Object { $_.text } | Where-Object { $_ -and $_.Trim() } | Sort-Object { $_.Length } -Descending)
$phrase = if ($lines.Count -gt 0) { $lines[0] } else { '' }
Log ('识别到台词: ' + $phrase)

if ([string]::IsNullOrWhiteSpace($phrase)) {
    LogErr '台词为空，无法提取关键词。'
    Read-Host '按回车退出' | Out-Null
    exit 3
}

# ---------- 4. 提取独特汉字/假名作关键词（2-4字，避开标点空格）----------
$clean = ($phrase -replace '[\s　、。，．！？!?「」『』（）()【】\[\]：:；;～~・…—\-~]', '')
# 取中间连续 3 个字，通常最能唯一命中该行
$keyword = ''
if ($clean.Length -ge 3) {
    $start = [Math]::Max(0, [Math]::Floor(($clean.Length - 3) / 2))
    $keyword = $clean.Substring($start, 3)
} elseif ($clean.Length -gt 0) {
    $keyword = $clean
}
Log ('搜索关键词: ' + $keyword)

# ---------- 5. 把关键词填进"选择文本"窗口的搜索框 ----------
# 选择窗口布局：表格在最上，下面第一排是 [搜索框][文本处理][游戏设置]。
# 用鼠标点击搜索框大致位置（表格下方约 20px），再 Ctrl+A 输入。
# 更稳妥：先用窗口句柄激活，再用 Tab 导航。这里用坐标点击（搜索框在窗口左下区域）。
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32 {
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, uint dwExtraInfo);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    public struct RECT { public int Left, Top, Right, Bottom; }
}
"@

[Win32]::ShowWindow($selWin.MainWindowHandle, 9) | Out-Null   # SW_RESTORE
[Win32]::SetForegroundWindow($selWin.MainWindowHandle) | Out-Null
Start-Sleep -Milliseconds 400

$r = New-Object Win32+RECT
[Win32]::GetWindowRect($selWin.MainWindowHandle, [ref]$r) | Out-Null

# 搜索框位于表格下方第一排。窗口底部往上约 70px 是第一排输入框。
# 取窗口左侧 + 120px, 底部 - 62px（经验值，适配默认布局）。
$clickX = $r.Left + 120
$clickY = $r.Bottom - 62
[Win32]::SetCursorPos($clickX, $clickY) | Out-Null
Start-Sleep -Milliseconds 150
[Win32]::mouse_event(0x0002, 0, 0, 0, 0)  # LEFTDOWN
[Win32]::mouse_event(0x0004, 0, 0, 0, 0)  # LEFTUP
Start-Sleep -Milliseconds 250

[System.Windows.Forms.SendKeys]::SendWait('^a')
[System.Windows.Forms.SendKeys]::SendWait($keyword)
Start-Sleep -Milliseconds 600

LogOk '已把关键词填入搜索框。'
Log '现在"选择文本"窗口里，只有抓到这句台词的那一列会保持可见。'
LogWarn '请在窗口里点那一行最左侧的开关（蓝色圆点），勾选后会自动翻译。'
Log ''
Log '选完后的关键一步：'
Log '  请正常关闭 LunaTranslator（点窗口 X 或托盘退出），不要强杀进程，配置才会保存。'
Log '  之后每次运行「一键玩Galgame.bat」即可自动开游戏+翻译，不用再选文本。'
Read-Host '按回车关闭本窗口' | Out-Null
