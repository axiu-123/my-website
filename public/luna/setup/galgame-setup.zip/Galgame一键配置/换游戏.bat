@echo off
chcp 65001 >nul
set "PS1=C:\Users\a1541\Desktop\aaa\desktop\galgame-translate.ps1"
set "DROPFILE=C:\Users\a1541\Desktop\aaa\desktop\drop-game-path.txt"
if not exist "%PS1%" goto NOPATH
if "%~1"=="" goto NOMENU
set "GALGAME_DROP_PATH=%*"
>"%DROPFILE%" echo %*
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -AddGame -GamePathEnv GALGAME_DROP_PATH -GamePathFile "%DROPFILE%"
goto END
:NOMENU
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -SwitchGame
goto END
:NOPATH
echo ERROR: galgame-translate.ps1 not found at %PS1%
:END
echo.
pause
