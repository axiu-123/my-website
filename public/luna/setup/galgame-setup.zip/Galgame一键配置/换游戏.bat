@echo off
chcp 65001 >nul
title 换游戏 - Galgame 一键翻译
set "PS1=%~dp0galgame-translate.ps1"
if not exist "%PS1%" (
  echo 错误：没有找到 galgame-translate.ps1
  echo 请确保本文件和 galgame-translate.ps1 放在同一个文件夹里。
  pause
  exit /b 1
)
echo.
echo ==========================================
echo   换游戏（从已保存的游戏里挑一个）
echo ==========================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -SwitchGame
echo.
timeout /t 5 >nul
