@echo off
chcp 65001 >nul
title 换游戏 - Galgame 一键翻译
set "PS1=%~dp0galgame-translate.ps1"
if not exist "%PS1%" (
  echo 错误：没有找到 galgame-translate.ps1
  echo 请确保本文件和 galgame-translate.ps1 放在同一个文件夹里。
  pause
  exit /b 1
)
echo.
echo ==========================================
echo   换游戏 / 添加新游戏
echo   小技巧：把新游戏的 exe 拖到本图标上可直接添加
echo ==========================================
echo.
if "%~1"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -SwitchGame
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -AddGame -GamePath "%~1"
)
echo.
timeout /t 5 >nul
