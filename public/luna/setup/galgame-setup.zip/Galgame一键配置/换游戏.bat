@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title 换游戏 - Galgame 一键翻译
set "PS1=%~dp0galgame-translate.ps1"
if not exist "!PS1!" (
  echo 错误：没有找到 galgame-translate.ps1
  echo 请把本文件和 galgame-translate.ps1、select-text-helper.ps1 放同一目录。
  pause
  exit /b 1
)
echo.
echo ==========================================
echo   换游戏 / 添加新游戏
echo   正确用法：把游戏 exe 拖到【本文件图标】上松开
echo   注意：不要拖进黑色命令行窗口，路径带空格会被拆开报错
echo ==========================================
echo.
set "ARGS=%*"
set "ARGS=!ARGS:"=!"
if not defined ARGS (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "!PS1!" -SwitchGame
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "!PS1!" -AddGame -GamePath "!ARGS!"
)
echo.
timeout /t 6 >nul
