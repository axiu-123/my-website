@echo off
chcp 65001 >nul
title 换游戏 - Galgame 一键翻译
set "PS1=%~dp0galgame-translate.ps1"
set "DROPFILE=%~dp0drop-game-path.txt"
if not exist "%PS1%" (
  echo 错误：没有找到 galgame-translate.ps1
  echo 请把本文件和 galgame-translate.ps1、select-text-helper.ps1 放同一目录。
  pause
  exit /b 1
)
echo.
echo ==========================================
echo   换游戏 / 添加新游戏
echo   用法：把游戏 exe 拖到【本文件图标】上松开
echo   或不拖任何东西、直接双击 = 打开换游戏菜单
echo ==========================================
echo.
if "%~1"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -SwitchGame
) else (
  echo 收到拖入的游戏：%~1
  rem 用环境变量传递完整路径（UTF-16，中文/空格不丢失），并写文件兜底
  set "GALGAME_DROP_PATH=%*"
  >"%DROPFILE%" echo %*
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -AddGame -GamePathEnv GALGAME_DROP_PATH -GamePathFile "%DROPFILE%"
)
echo.
echo ==========================================
pause
