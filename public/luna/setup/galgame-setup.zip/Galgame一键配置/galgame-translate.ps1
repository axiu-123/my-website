﻿<#
.SYNOPSIS
    Galgame 一键翻译：配置 LunaTranslator 网络服务 + HOOK 模式，并用 --Exec 启动已保存 hook 的游戏。
.DESCRIPTION
    对话只走 HOOK；标题/贴图选项走「进行一次OCR」快捷键 F8（LT 的文本源互斥，不能同时开）。
    只针对 galgame。配置全包，首次需人工选一次文本行（LT 硬限制），之后全自动。
    出网仅为 LT 自身翻译引擎（独立第三方软件），不改动桌宠本体任何出网约定。
.PARAMETER ConfigOnly
    只做配置并重启 LunaTranslator（不启动游戏）。用于首次配置或验证。
.PARAMETER DryRun
    只打印将要执行的操作，不修改文件、不启动进程。
.PARAMETER GameUid
    指定要启动的游戏 uid（savegamedata 里的 key）。默认取上次玩过的游戏。
.PARAMETER SwitchGame
    换游戏模式：列出存档里所有游戏（含"需首次选文本"的），让你选一个；也可输入 exe 路径添加新游戏。选择会记住。
.PARAMETER List
    只列出可选游戏，不启动、不修改。
.PARAMETER AddGame
    把一个新游戏 exe 加进 LT 存档并直接启动（首次会自动弹"选择文本"窗口）。可传 exe 路径参数；不传则提示输入。
#>
param(
    [switch]$ConfigOnly,
    [switch]$DryRun,
    [string]$GameUid = '',
    [switch]$SwitchGame,
    [switch]$List,
    [switch]$AddGame,
    [string]$GamePath = '',
    [string]$GamePathFile = '',
    [string]$GamePathEnv = ''
)

$ErrorActionPreference = 'Stop'
# List 模式也要只读：不关进程、不写配置
$noWrite = ($DryRun -or $List)

function Log([string]$m)      { Write-Host ('[GalTrans] ' + $m) }
function LogOk([string]$m)    { Write-Host ('[GalTrans] ' + $m) -ForegroundColor Green }
function LogWarn([string]$m)  { Write-Host ('[GalTrans] ' + $m) -ForegroundColor Yellow }
function LogErr([string]$m)   { Write-Host ('[GalTrans] ' + $m) -ForegroundColor Red }

Log '=== Galgame 一键翻译 ==='

# ---------- 1. 定位 LunaTranslator ----------
$exe = $null
$root = $null
$running = Get-Process -Name 'LunaTranslator' -ErrorAction SilentlyContinue | Where-Object { $_.Path } | Select-Object -First 1
if ($running) { $exe = $running.Path; $root = Split-Path -Parent $exe }

if (-not $exe) {
    $cands = @(
        (Join-Path $PSScriptRoot 'LunaTranslator.exe'),
        (Join-Path $PSScriptRoot 'LunaTranslator_x64\LunaTranslator.exe'),
        (Join-Path $env:USERPROFILE 'Desktop\LunaTranslator_x64\LunaTranslator.exe'),
        (Join-Path $env:USERPROFILE 'Downloads\LunaTranslator_x64\LunaTranslator.exe'),
        (Join-Path $env:USERPROFILE 'Downloads\LunaTranslator\LunaTranslator.exe'),
        'D:\LunaTranslator_x64\LunaTranslator.exe',
        'C:\LunaTranslator_x64\LunaTranslator.exe'
    )
    foreach ($c in $cands) { if (Test-Path -LiteralPath $c) { $exe = $c; $root = Split-Path -Parent $c; break } }
}

if (-not $exe) {
    LogErr '未找到 LunaTranslator.exe。'
    LogWarn '请把本脚本放到 LunaTranslator 解压目录（和 LunaTranslator.exe 同一层）后重试。'
    if (-not $DryRun) { Read-Host '按回车退出' | Out-Null }
    exit 1
}
Log ('安装目录: ' + $root)

$userCfgDir = Join-Path $root 'userconfig'
$userCfg    = Join-Path $userCfgDir 'config.json'
$defaultCfg = Join-Path $root 'LunaTranslator\defaultconfig\config.json'
# savegamedata 文件名带版本号（如 savegamedata_5.3.1.json），用通配匹配避免版本升级后失效
$saveData = $null
$sdCand = Get-ChildItem -LiteralPath $userCfgDir -Filter 'savegamedata_*.json' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
if ($sdCand) { $saveData = $sdCand.FullName }

# "上次玩的游戏"记忆文件：LT 存档本身只记创建时间、不记最近游玩，所以由脚本自己记。
# 放在脚本同目录；换游戏时更新，双击默认接着玩上次那个。
$lastGameFile = Join-Path $PSScriptRoot 'last-game.txt'
function Get-LastGameUid {
    if (Test-Path -LiteralPath $lastGameFile) {
        $v = (Get-Content -LiteralPath $lastGameFile -Raw -Encoding UTF8).Trim()
        if ($v) { return $v }
    }
    return ''
}
function Set-LastGameUid([string]$uid) {
    try { [System.IO.File]::WriteAllText($lastGameFile, $uid, (New-Object System.Text.UTF8Encoding($false))) } catch {}
}

# 把一个新游戏 exe 路径加入 LT 存档。LT 存档格式：[uid列表, {uid: {字段...}}, tags...]
# 新增游戏只需：列表尾部加 uid，data 里加 {createtime, gamepath, title}。uid 格式 "时间戳_uuid"（与 LT 自身一致）。
function Add-GameToSave([string]$path) {
    if (-not $saveData -or -not (Test-Path -LiteralPath $saveData)) {
        LogErr '找不到 savegamedata 存档文件，无法添加新游戏。请先手动把一个游戏拖进 LT 让它生成存档。'
        return $null
    }
    if (-not (Test-Path -LiteralPath $path)) { LogErr ('游戏路径不存在: ' + $path); return $null }
    $full = (Resolve-Path -LiteralPath $path).Path
    try {
        $arr = (Get-Content -LiteralPath $saveData -Raw -Encoding UTF8) | ConvertFrom-Json
        $list = @($arr[0])
        $data = $arr[1]

        # 已有同路径游戏则直接复用其 uid（不重复添加）
        foreach ($u in $list) {
            $p = $data.PSObject.Properties[$u]
            if ($p -and $p.Value.PSObject.Properties['gamepath'] -and $p.Value.gamepath) {
                $normA = ([string]$p.Value.gamepath).TrimEnd('\','/').ToLower()
                $normB = $full.TrimEnd('\','/').ToLower()
                if ($normA -eq $normB) { Log ('该游戏已在存档中，直接启动: ' + $p.Value.title); return $u }
            }
        }

        $ts = [double]::Parse((Get-Date -UFormat %s))
        $uid = $ts.ToString() + '_' + [guid]::NewGuid().ToString()
        $title = [System.IO.Path]::GetFileName($full)
        $entry = [PSCustomObject]@{
            createtime = $ts
            gamepath   = $full
            title      = $title
        }
        # 备份存档后写入
        Copy-Item -LiteralPath $saveData -Destination ($saveData + '.galtrans.bak') -Force
        $newList = @($list) + @($uid)
        $data | Add-Member -NotePropertyName $uid -NotePropertyValue $entry
        # 关键：用 ArrayList 构造顶层裸数组，避免 PowerShell 把多个参数包成 {"value":..,"Count":..}。
        # LT 期望格式 [uid列表, {uid:dict}, tags...]，顶层必须是数组。
        $outArr = New-Object System.Collections.ArrayList
        [void]$outArr.Add($newList)
        [void]$outArr.Add($data)
        if ($arr.Count -gt 2) { for ($k=2; $k -lt $arr.Count; $k++) { [void]$outArr.Add($arr[$k]) } }
        $json = ConvertTo-Json -InputObject $outArr -Depth 100 -Compress
        [System.IO.File]::WriteAllText($saveData, $json, (New-Object System.Text.UTF8Encoding($false)))
        LogOk ('已把新游戏加入存档: ' + $title)
        Log ('  路径: ' + $full)
        return $uid
    } catch {
        LogErr ('添加游戏失败: ' + $_.Exception.Message)
        return $null
    }
}

# ---------- 2. 关闭旧进程（配置必须先关，否则退出时会覆盖我们的修改）----------
# 关键修复：绝不无条件 Stop-Process -Force。
# LT 只在"正常退出"时把选好的 hook 写回存档（translatorUI.closeEvent -> saveallconfig）。
# 强杀会让刚选好的文本行丢失——这正是"hook 数一直是 0 / 每次都像手动"的真凶。
# 现在改成：先温和退出 -> 轮询等进程自己结束 + 存档 mtime 变化 -> 超时才强杀并明确告警。
$needRestart = $false
if (-not $noWrite) {
    $procs = @(Get-Process -Name 'LunaTranslator' -ErrorAction SilentlyContinue | Where-Object { $_.Path })
    if ($procs.Count -gt 0) {
        # 记录存档修改时间，用于判断是否真的落盘
        $sdMtimeBefore = $null
        if ($saveData -and (Test-Path -LiteralPath $saveData)) {
            $sdMtimeBefore = (Get-Item -LiteralPath $saveData).LastWriteTime
        }

        foreach ($p in $procs) {
            try { $p.CloseMainWindow() | Out-Null } catch {}
            # LT 常驻托盘时 MainWindowHandle=0，CloseMainWindow() 无效。
            # taskkill 不带 /F 同样只发 WM_CLOSE，会触发 Qt 的 saveallconfig() 落盘。
            try { & taskkill.exe /PID $p.Id | Out-Null } catch {}
        }

        # 最多等 12 秒，让 LT 走完正常退出 + 落盘
        $waited = 0
        while ($waited -lt 12) {
            Start-Sleep -Seconds 1
            $waited++
            $alive = @(Get-Process -Name 'LunaTranslator' -ErrorAction SilentlyContinue | Where-Object { $_.Path })
            if ($alive.Count -eq 0) { break }
        }

        $stillAlive = @(Get-Process -Name 'LunaTranslator' -ErrorAction SilentlyContinue | Where-Object { $_.Path })
        if ($stillAlive.Count -gt 0) {
            LogWarn 'LunaTranslator 12 秒未正常退出。这可能是上次选完文本还没落盘。'
            LogWarn '为保护存档，本次不强制杀进程。请手动到托盘图标点"退出"后重跑本脚本。'
            exit 4
        }

        # 校验存档是否落盘
        if ($sdMtimeBefore -and $saveData -and (Test-Path -LiteralPath $saveData)) {
            $sdMtimeAfter = (Get-Item -LiteralPath $saveData).LastWriteTime
            if ($sdMtimeAfter -gt $sdMtimeBefore) {
                LogOk '检测到配置存档已正常保存（hook 选择已固化）。'
            } else {
                LogWarn '存档时间戳未变化：如果刚选过文本，可能仍未写入，请留意下方 hook 校验结果。'
            }
        }

        # 主进程退出后，残留子进程可安全清理
        Stop-Process -Name 'LunaSubprocess64','LunaSubprocess32' -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
        Log '已温和关闭旧的 LunaTranslator 进程（存档已保留）。'
        $needRestart = $true
    }
}

# ---------- 3. 配置（幂等）----------
# List/DryRun 只读模式：不检查、不生成 config，直接跳过配置段
if (-not $noWrite -and -not (Test-Path -LiteralPath $userCfg)) {
    if (Test-Path -LiteralPath $defaultCfg) {
        if (-not $noWrite) {
            if (-not (Test-Path -LiteralPath $userCfgDir)) { New-Item -ItemType Directory -Path $userCfgDir -Force | Out-Null }
            Copy-Item -LiteralPath $defaultCfg -Destination $userCfg -Force
            Log '从默认配置创建了 config.json。'
        }
    } else {
        LogErr 'defaultconfig\config.json 不存在，无法生成用户配置。'
        if (-not $noWrite) { Read-Host '按回车退出' | Out-Null }
        exit 1
    }
}

if ($noWrite) {
    if ($DryRun) {
        Log '[DryRun] 将写入 config.json:'
        Log '  networktcpenable=true  networktcpport=2333  network=1  network_websocket=1'
        Log '  fanyi.caiyun.use=true（彩云整句翻译，免费无key）'
        Log '  sourcestatus2.texthook.use=true, ocr.use=false（LT 文本源互斥）'
        Log '  快捷键 F8=进行一次OCR（框选标题/选项，译文内嵌在框选位置），Ctrl+Alt+F8=再次进行OCR'
    }
} else {
    Copy-Item -LiteralPath $userCfg -Destination ($userCfg + '.galtrans.bak') -Force
    $raw = Get-Content -LiteralPath $userCfg -Raw -Encoding UTF8
    $cfg = $raw | ConvertFrom-Json

    # 网络服务（桌宠靠 127.0.0.1:2333 收文本）
    $cfg | Add-Member -NotePropertyName 'networktcpenable'  -NotePropertyValue $true -Force
    $cfg | Add-Member -NotePropertyName 'networktcpport'    -NotePropertyValue 2333  -Force
    $cfg | Add-Member -NotePropertyName 'network'           -NotePropertyValue 1     -Force
    $cfg | Add-Member -NotePropertyName 'network_websocket' -NotePropertyValue 1     -Force

    # 翻译引擎：启用彩云（免费无key、国内直连、实测可翻日语整句）
    if (-not $cfg.fanyi) { $cfg | Add-Member -NotePropertyName 'fanyi' -NotePropertyValue ([PSCustomObject]@{}) -Force }
    if (-not $cfg.fanyi.caiyun) { $cfg.fanyi | Add-Member -NotePropertyName 'caiyun' -NotePropertyValue ([PSCustomObject]@{ name='彩云'; color='blue'; useproxy=$false }) -Force }
    $cfg.fanyi.caiyun | Add-Member -NotePropertyName 'use' -NotePropertyValue $true -Force
    # 关掉空的人工翻译表，避免它抢占翻译顺序
    if ($cfg.fanyi.rengong) { $cfg.fanyi.rengong | Add-Member -NotePropertyName 'use' -NotePropertyValue $false -Force }

    # 文本源：只能开一个。LT 源码 yuitsu_switch() 会把其它源 use 全设为 false，
    # starttextsource() 也只取第一个 use=true 的源。之前把 HOOK 和 OCR 同时设 true，
    # LT 实际按 classes 顺序取了 ocr，HOOK 对话反而停了；而 OCR 源的 F8 触发器
    # 又要求画面静止（MSSIM>0.95），游戏一动就永远不触发 —— 所以按 F8 没反应。
    # 现在只开 HOOK 做对话；标题/贴图选项改走「进行一次OCR」快捷键（见下方 _26）。
    if (-not $cfg.sourcestatus2) {
        $cfg | Add-Member -NotePropertyName 'sourcestatus2' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    if (-not $cfg.sourcestatus2.texthook) {
        $cfg.sourcestatus2 | Add-Member -NotePropertyName 'texthook' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    if (-not $cfg.sourcestatus2.ocr) {
        $cfg.sourcestatus2 | Add-Member -NotePropertyName 'ocr' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    $cfg.sourcestatus2.texthook | Add-Member -NotePropertyName 'use' -NotePropertyValue $true  -Force
    $cfg.sourcestatus2.ocr      | Add-Member -NotePropertyName 'use' -NotePropertyValue $false -Force

    # F8 = 「进行一次OCR」：LT 进入框选，框住标题/选项后识别 + 翻译。
    # 它不占用文本源，和 HOOK 并行不冲突；ocr_do_function 走 graph.textgetmethod，
    # 译文同样进网络服务，桌宠 2333 能收到。
    # Ctrl+Alt+F8 = 「再次进行OCR」：同一位置重识别（选项刷新后不用重新框）。
    if (-not $cfg.quick_setting) {
        $cfg | Add-Member -NotePropertyName 'quick_setting' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    if (-not $cfg.quick_setting.all) {
        $cfg.quick_setting | Add-Member -NotePropertyName 'all' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    $cfg.quick_setting | Add-Member -NotePropertyName 'use' -NotePropertyValue $true -Force

    $k1 = $cfg.quick_setting.all.PSObject.Properties['_26']
    if (-not $k1) {
        $cfg.quick_setting.all | Add-Member -NotePropertyName '_26' -NotePropertyValue ([PSCustomObject]@{ name='进行一次OCR' }) -Force
        $k1 = $cfg.quick_setting.all.PSObject.Properties['_26']
    }
    $k1.Value | Add-Member -NotePropertyName 'use'       -NotePropertyValue $true -Force
    $k1.Value | Add-Member -NotePropertyName 'keystring' -NotePropertyValue 'F8' -Force

    $k2 = $cfg.quick_setting.all.PSObject.Properties['_26_1']
    if (-not $k2) {
        $cfg.quick_setting.all | Add-Member -NotePropertyName '_26_1' -NotePropertyValue ([PSCustomObject]@{ name='再次进行OCR' }) -Force
        $k2 = $cfg.quick_setting.all.PSObject.Properties['_26_1']
    }
    $k2.Value | Add-Member -NotePropertyName 'use'       -NotePropertyValue $true -Force
    $k2.Value | Add-Member -NotePropertyName 'keystring' -NotePropertyValue 'CTRL+ALT+F8' -Force

    # 原地显示翻译：F8 快捷键走 ocr_once_hotkey_function，此开关决定
    # 是 ocr_once_box_function（框内原地显示译文）还是普通单次OCR（只送桌宠）。
    # 源码 overlay_source_displays() 第一步就排除非 OCR 来源，HOOK 对话译文不受影响。
    $cfg | Add-Member -NotePropertyName 'ocr_translation_overlay' -NotePropertyValue $true -Force
    # 目标语言中文
    $cfg | Add-Member -NotePropertyName 'tgtlang4' -NotePropertyValue 'zh' -Force
    $cfg | Add-Member -NotePropertyName 'languageuse2' -NotePropertyValue 'zh' -Force

    # 让网络服务开关在设置里展开，避免以后又找不到（纯 UI，无副作用）
    if ($cfg.foldstatus -and $cfg.foldstatus.others) {
        $cfg.foldstatus.others | Add-Member -NotePropertyName 'netservice' -NotePropertyValue $false -Force
    }

    $out = $cfg | ConvertTo-Json -Depth 100
    [System.IO.File]::WriteAllText($userCfg, $out, (New-Object System.Text.UTF8Encoding($false)))
    LogOk '配置已写入：网络服务(2333) + 彩云翻译 + HOOK对话 + F8框选OCR(标题/选项)。'
    Log '原配置已备份到 config.json.galtrans.bak'
}

# ---------- 4. 找已保存 hook 的 galgame ----------
function Get-HookedGames {
    if (-not (Test-Path -LiteralPath $saveData)) { return @() }
    try {
        $arr = (Get-Content -LiteralPath $saveData -Raw -Encoding UTF8) | ConvertFrom-Json
        $list = $arr[0]
        $data = $arr[1]
        $res = @()
        foreach ($uid in $list) {
            $prop = $data.PSObject.Properties[$uid]
            if (-not $prop) { continue }
            $g = $prop.Value
            $hookCount = 0
            if ($g.PSObject.Properties['hook'] -and $null -ne $g.hook) { $hookCount = @($g.hook).Count }
            $ttl = '(无标题)'
            if ($g.PSObject.Properties['title'] -and $g.title) { $ttl = $g.title }
            $gp = ''
            if ($g.PSObject.Properties['gamepath'] -and $g.gamepath) { $gp = $g.gamepath }
            $res += [PSCustomObject]@{
                Uid       = $uid
                Title     = $ttl
                GamePath  = $gp
                HookCount = $hookCount
            }
        }
        return $res
    } catch {
        LogWarn ('读取游戏列表失败: ' + $_.Exception.Message)
        return @()
    }
}

$allGames = @(Get-HookedGames)
$hooked = $allGames | Where-Object { $_.HookCount -gt 0 }

# 存档状态一览：让用户清楚看到"哪款游戏已经永久保存了文本选择"
if ($allGames.Count -gt 0) {
    Log '存档里的游戏（hook=0 表示还没选过文本，>0 表示已永久保存）:'
    foreach ($g in $allGames) {
        if ($g.HookCount -gt 0) {
            LogOk ('  ✔ ' + $g.Title + '  (hook=' + $g.HookCount + ') —— 已保存，可全自动')
        } else {
            LogWarn ('  ○ ' + $g.Title + '  (hook=0) —— 还需首次选一次文本')
        }
    }
}

if ($DryRun) {
    Log ('[DryRun] 带 hook 的游戏数: ' + @($hooked).Count)
    foreach ($g in $hooked) { Log ('  - ' + $g.Title + '  (hook=' + $g.HookCount + ')') }
}

# ---------- 5. 启动 ----------
if ($DryRun) {
    Log '[DryRun] 结束（未修改、未启动）。'
    exit 0
}

if ($List) {
    Log '可选游戏（带 hook = 可直接全自动）:'
    $i = 0
    foreach ($g in $allGames) {
        $i++
        $mark = if ($g.HookCount -gt 0) { '✔ 可玩' } else { '○ 需首次选文本' }
        Log ('  [' + $i + '] ' + $mark + '  ' + $g.Title)
    }
    $lastUid = Get-LastGameUid
    if ($lastUid) {
        $lg = $allGames | Where-Object { $_.Uid -eq $lastUid } | Select-Object -First 1
        if ($lg) { Log ('上次玩的是: ' + $lg.Title) }
    }
    exit 0
}

if ($ConfigOnly) {
    # 只配置：重启 LT，不启动游戏
    Start-Process -FilePath $exe
    Log '已启动 LunaTranslator（仅配置模式，未启动游戏）。'
} else {
    $target = $null
    if ($GameUid) {
        $target = $allGames | Where-Object { $_.Uid -eq $GameUid } | Select-Object -First 1
        if (-not $target) { LogWarn ('指定的 GameUid 未找到: ' + $GameUid) }
    }

    # 添加新游戏模式：把 exe 路径写进存档，然后走首次选文本流程
    if (-not $target -and $AddGame) {
        $p = $GamePath
        # 拖放专用：优先从环境变量读（cmd 传中文路径时环境变量保留 UTF-16 原样，最可靠）
        if (-not $p -and $GamePathEnv) {
            $ev = [System.Environment]::GetEnvironmentVariable($GamePathEnv)
            if ($ev) { $p = $ev.Trim('"',' '); Log ('从环境变量读到游戏路径: ' + $p) }
        }
        # 兜底：从 bat 写入的路径文件读取
        if (-not $p -and $GamePathFile -and (Test-Path -LiteralPath $GamePathFile)) {
            try {
                $raw = [System.IO.File]::ReadAllText($GamePathFile, [System.Text.UTF8Encoding]::new($false)).Trim()
                $p = $raw.Trim('"',' ')
                Log ('从拖放文件读到游戏路径: ' + $p)
            } catch { LogWarn ('读取拖放路径文件失败: ' + $_.Exception.Message) }
        }
        if (-not $p) {
            Log '把新游戏的 exe 拖进本窗口回车，或手动输入完整路径：'
            $p = Read-Host '游戏 exe 路径'
        }
        if ($p) {
            $p = $p.Trim('"',' ')
            $newUid = Add-GameToSave $p
            if ($newUid) {
                Set-LastGameUid $newUid
                $target = [PSCustomObject]@{ Uid=$newUid; Title=[System.IO.Path]::GetFileName($p); GamePath=$p; HookCount=0 }
            }
        }
    }

    # 换游戏模式：列出存档里所有游戏（含 hook=0 需首次选文本的），让用户选
    if (-not $target -and $SwitchGame) {
        $playable = @($allGames)
        if ($playable.Count -gt 0) {
            Log '=== 换游戏：选一个要玩的 ==='
            for ($i = 0; $i -lt $playable.Count; $i++) {
                $tag = if ($playable[$i].HookCount -gt 0) { '可全自动' } else { '需首次选文本' }
                Log ('  [' + ($i + 1) + '] ' + $playable[$i].Title + '  (' + $tag + ')')
            }
            Log '  [A] 添加新游戏（输入 exe 路径，首次会自动弹选文本窗口）'
            $choice = (Read-Host '输入序号 或 A（回车=取消）').Trim()
            if ($choice -match '^\d+$') {
                $idx = [int]$choice - 1
                if ($idx -ge 0 -and $idx -lt $playable.Count) { $target = $playable[$idx] }
            } elseif ($choice -match '^[Aa]$') {
                Log '把新游戏的 exe 拖进本窗口回车，或手动输入完整路径：'
                $p = (Read-Host '游戏 exe 路径').Trim('"',' ')
                if ($p) {
                    $newUid = Add-GameToSave $p
                    if ($newUid) {
                        Set-LastGameUid $newUid
                        $target = [PSCustomObject]@{ Uid=$newUid; Title=[System.IO.Path]::GetFileName($p); GamePath=$p; HookCount=0 }
                    }
                }
            }
            if (-not $target) { Log '已取消。'; exit 0 }
        }
    }

    # 默认：接着上次玩的游戏（含 hook=0 的也接着弄）；失效才回退到第一个带 hook 的
    if (-not $target) {
        $lastUid = Get-LastGameUid
        if ($lastUid) {
            $target = $allGames | Where-Object { $_.Uid -eq $lastUid } | Select-Object -First 1
        }
    }
    if (-not $target) { $target = $hooked | Select-Object -First 1 }

    if ($target) {
        Set-LastGameUid $target.Uid
        if ($target.HookCount -gt 0) {
            # 已保存 hook：--Exec 自动开游戏 + 套用 hook，直接翻译
            Log ('启动游戏（自动 HOOK）: ' + $target.Title)
            Log ('  游戏路径: ' + $target.GamePath)
            Start-Process -FilePath $exe -ArgumentList @('--Exec', $target.Uid)
        } else {
            # hook=0（含刚添加的新游戏）：--Exec 启动并注入 HOOK，LT 会自动弹"选择文本"窗口
            LogWarn ('《' + $target.Title + '》还没选过文本，这是第一次玩 —— 只做这一次，之后永久免做。')
            Log ('启动游戏（首次会自动弹"选择文本"窗口）: ' + $target.Title)
            Log ('  游戏路径: ' + $target.GamePath)
            Start-Process -FilePath $exe -ArgumentList @('--Exec', $target.Uid)

            # 自动拉起"选文本助手"：等 LT 注入后弹选择文本窗口，然后自动打开助手窗口。
            # 用户不再需要单独双击助手 bat —— 这就是把两个入口合并的关键。
            $helperPs1 = Join-Path $PSScriptRoot 'select-text-helper.ps1'
            Log '等待"选择文本"窗口弹出（LT 注入游戏后会自动弹）...'
            $selWin = $null
            for ($w=0; $w -lt 90; $w++) {
                Start-Sleep -Seconds 1
                $selWin = Get-Process | Where-Object { $_.MainWindowTitle -and $_.MainWindowTitle -like '*选择文本*' } | Select-Object -First 1
                if ($selWin) { break }
            }
            if ($selWin) {
                LogOk '已弹出"选择文本"窗口，正在自动打开选文本助手...'
                if (Test-Path -LiteralPath $helperPs1) {
                    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File', ('"' + $helperPs1 + '"'))
                    Log '跟着助手窗口提示做：把游戏推进到有对话的一句 -> 回车 -> 点唯一那行 -> 正常退出 LT。'
                } else {
                    LogWarn ('找不到 select-text-helper.ps1，请把脚本放在同一目录: ' + $helperPs1)
                }
            } else {
                LogWarn '等了 90 秒还没看到"选择文本"窗口。可能游戏未正常注入，请把游戏 exe 手动拖进 LT 窗口。'
            }
            LogWarn '选完后一定要"正常退出" LT（点 X / 托盘退出），不要强杀进程，否则 hook 存不上。'
        }
    } else {
        LogWarn '存档里还没有任何游戏。用下面任一方式添加第一个游戏：'
        Log '  方式1：把游戏 exe 拖进 LunaTranslator 窗口（LT 官方方式）'
        Log '  方式2：双击「换游戏.bat」，选 [A] 添加新游戏，输入 exe 路径'
        Start-Process -FilePath $exe
    }
}

# ---------- 6. 验证端口 ----------
$ok = $false
for ($i = 0; $i -lt 15; $i++) {
    Start-Sleep -Seconds 1
    try {
        $r = Invoke-WebRequest -Uri 'http://127.0.0.1:2333/' -TimeoutSec 3 -UseBasicParsing
        if ($r.StatusCode -eq 200) { $ok = $true; break }
    } catch {}
}
if ($ok) {
    LogOk 'SUCCESS: 网络服务 127.0.0.1:2333 已就绪。'
    LogOk '对话译文会自动送到桌宠，按 Ctrl+Alt+T 显示字幕浮层。'
    Log '标题/贴图选项：按 F8 → 鼠标框住那块文字 → 译文直接画在框选位置（内嵌，和原文对得上）。'
    Log '同一位置选项变了：按 Ctrl+Alt+F8 重识别；译文框点一下鼠标就关闭。'
    Log '提示：想换别的游戏玩，双击「换游戏.bat」从列表选；以后默认还玩这次这个。'
} else {
    LogWarn '端口 2333 15 秒内未响应。请看 LunaTranslator 窗口是否有报错。'
}

if (-not $PSBoundParameters.ContainsKey('DryRun')) {
    Log '本窗口可关闭。'
}
