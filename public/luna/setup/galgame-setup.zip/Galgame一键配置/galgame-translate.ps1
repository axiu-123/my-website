﻿<#
.SYNOPSIS
    Galgame 一键翻译：配置 LunaTranslator 网络服务 + HOOK 模式，并用 --Exec 启动已保存 hook 的游戏。
.DESCRIPTION
    只做 HOOK、只针对 galgame。配置全包，首次需人工选一次文本行（LT 硬限制），之后全自动。
    出网仅为 LT 自身翻译引擎（独立第三方软件），不改动桌宠本体任何出网约定。
.PARAMETER ConfigOnly
    只做配置并重启 LunaTranslator（不启动游戏）。用于首次配置或验证。
.PARAMETER DryRun
    只打印将要执行的操作，不修改文件、不启动进程。
.PARAMETER GameUid
    指定要启动的游戏 uid（savegamedata 里的 key）。默认取最近一个带 hook 的游戏。
#>
param(
    [switch]$ConfigOnly,
    [switch]$DryRun,
    [string]$GameUid = ''
)

$ErrorActionPreference = 'Stop'

function Log([string]$m)      { Write-Host ('[GalTrans] ' + $m) }
function LogOk([string]$m)    { Write-Host ('[GalTrans] ' + $m) -ForegroundColor Green }
function LogWarn([string]$m)  { Write-Host ('[GalTrans] ' + $m) -ForegroundColor Yellow }
function LogErr([string]$m)   { Write-Host ('[GalTrans] ' + $m) -ForegroundColor Red }

Log '=== Galgame 一键翻译 ==='

# ---------- 1. 定位 LunaTranslator ----------
$exe = $null
$root = $null
$running = Get-Process -Name 'LunaTranslator' -ErrorAction SilentlyContinue | Where-Object { $_.Path } | Select-Object -First 1
if ($running) { $exe = $running.Path; $root = Split-Path -Parent $exe }

if (-not $exe) {
    $cands = @(
        (Join-Path $PSScriptRoot 'LunaTranslator.exe'),
        (Join-Path $PSScriptRoot 'LunaTranslator_x64\LunaTranslator.exe'),
        (Join-Path $env:USERPROFILE 'Desktop\LunaTranslator_x64\LunaTranslator.exe'),
        (Join-Path $env:USERPROFILE 'Downloads\LunaTranslator_x64\LunaTranslator.exe'),
        (Join-Path $env:USERPROFILE 'Downloads\LunaTranslator\LunaTranslator.exe'),
        'D:\LunaTranslator_x64\LunaTranslator.exe',
        'C:\LunaTranslator_x64\LunaTranslator.exe'
    )
    foreach ($c in $cands) { if (Test-Path -LiteralPath $c) { $exe = $c; $root = Split-Path -Parent $c; break } }
}

if (-not $exe) {
    LogErr '未找到 LunaTranslator.exe。'
    LogWarn '请把本脚本放到 LunaTranslator 解压目录（和 LunaTranslator.exe 同一层）后重试。'
    if (-not $DryRun) { Read-Host '按回车退出' | Out-Null }
    exit 1
}
Log ('安装目录: ' + $root)

$userCfgDir = Join-Path $root 'userconfig'
$userCfg    = Join-Path $userCfgDir 'config.json'
$defaultCfg = Join-Path $root 'LunaTranslator\defaultconfig\config.json'
# savegamedata 文件名带版本号（如 savegamedata_5.3.1.json），用通配匹配避免版本升级后失效
$saveData = $null
$sdCand = Get-ChildItem -LiteralPath $userCfgDir -Filter 'savegamedata_*.json' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
if ($sdCand) { $saveData = $sdCand.FullName }

# ---------- 2. 关闭旧进程（配置必须先关，否则退出时会覆盖我们的修改）----------
$needRestart = $false
if (-not $DryRun) {
    $procs = Get-Process -Name 'LunaTranslator','LunaSubprocess64','LunaSubprocess32' -ErrorAction SilentlyContinue
    if ($procs) {
        foreach ($p in $procs) { try { $p.CloseMainWindow() | Out-Null } catch {} }
        Start-Sleep -Seconds 2
        Stop-Process -Name 'LunaTranslator','LunaSubprocess64','LunaSubprocess32' -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 800
        Log '已关闭旧的 LunaTranslator 进程。'
        $needRestart = $true
    }
}

# ---------- 3. 配置（幂等）----------
if (-not (Test-Path -LiteralPath $userCfg)) {
    if (Test-Path -LiteralPath $defaultCfg) {
        if (-not $DryRun) {
            if (-not (Test-Path -LiteralPath $userCfgDir)) { New-Item -ItemType Directory -Path $userCfgDir -Force | Out-Null }
            Copy-Item -LiteralPath $defaultCfg -Destination $userCfg -Force
            Log '从默认配置创建了 config.json。'
        }
    } else {
        LogErr 'defaultconfig\config.json 不存在，无法生成用户配置。'
        if (-not $DryRun) { Read-Host '按回车退出' | Out-Null }
        exit 1
    }
}

if ($DryRun) {
    Log '[DryRun] 将写入 config.json:'
    Log '  networktcpenable=true  networktcpport=2333  network=1  network_websocket=1'
    Log '  sourcestatus2.texthook.use=true  sourcestatus2.ocr.use=false'
} else {
    Copy-Item -LiteralPath $userCfg -Destination ($userCfg + '.galtrans.bak') -Force
    $raw = Get-Content -LiteralPath $userCfg -Raw -Encoding UTF8
    $cfg = $raw | ConvertFrom-Json

    # 网络服务（桌宠靠 127.0.0.1:2333 收文本）
    $cfg | Add-Member -NotePropertyName 'networktcpenable'  -NotePropertyValue $true -Force
    $cfg | Add-Member -NotePropertyName 'networktcpport'    -NotePropertyValue 2333  -Force
    $cfg | Add-Member -NotePropertyName 'network'           -NotePropertyValue 1     -Force
    $cfg | Add-Member -NotePropertyName 'network_websocket' -NotePropertyValue 1     -Force

    # 文本输入切到 HOOK（texthook=true, ocr=false）；只做 galgame，不做 OCR
    if (-not $cfg.sourcestatus2) {
        $cfg | Add-Member -NotePropertyName 'sourcestatus2' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    if (-not $cfg.sourcestatus2.texthook) {
        $cfg.sourcestatus2 | Add-Member -NotePropertyName 'texthook' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    if (-not $cfg.sourcestatus2.ocr) {
        $cfg.sourcestatus2 | Add-Member -NotePropertyName 'ocr' -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    $cfg.sourcestatus2.texthook | Add-Member -NotePropertyName 'use' -NotePropertyValue $true  -Force
    $cfg.sourcestatus2.ocr      | Add-Member -NotePropertyName 'use' -NotePropertyValue $false -Force

    # 让网络服务开关在设置里展开，避免以后又找不到（纯 UI，无副作用）
    if ($cfg.foldstatus -and $cfg.foldstatus.others) {
        $cfg.foldstatus.others | Add-Member -NotePropertyName 'netservice' -NotePropertyValue $false -Force
    }

    $out = $cfg | ConvertTo-Json -Depth 100
    [System.IO.File]::WriteAllText($userCfg, $out, (New-Object System.Text.UTF8Encoding($false)))
    LogOk '配置已写入：网络服务开(2333) + HOOK模式 开 + OCR 关。'
    Log '原配置已备份到 config.json.galtrans.bak'
}

# ---------- 4. 找已保存 hook 的 galgame ----------
function Get-HookedGames {
    if (-not (Test-Path -LiteralPath $saveData)) { return @() }
    try {
        $arr = (Get-Content -LiteralPath $saveData -Raw -Encoding UTF8) | ConvertFrom-Json
        $list = $arr[0]
        $data = $arr[1]
        $res = @()
        foreach ($uid in $list) {
            $prop = $data.PSObject.Properties[$uid]
            if (-not $prop) { continue }
            $g = $prop.Value
            $hookCount = 0
            if ($g.PSObject.Properties['hook'] -and $null -ne $g.hook) { $hookCount = @($g.hook).Count }
            $ttl = '(无标题)'
            if ($g.PSObject.Properties['title'] -and $g.title) { $ttl = $g.title }
            $gp = ''
            if ($g.PSObject.Properties['gamepath'] -and $g.gamepath) { $gp = $g.gamepath }
            $res += [PSCustomObject]@{
                Uid       = $uid
                Title     = $ttl
                GamePath  = $gp
                HookCount = $hookCount
            }
        }
        return $res
    } catch {
        LogWarn ('读取游戏列表失败: ' + $_.Exception.Message)
        return @()
    }
}

$hooked = Get-HookedGames | Where-Object { $_.HookCount -gt 0 }

if ($DryRun) {
    Log ('[DryRun] 带 hook 的游戏数: ' + @($hooked).Count)
    foreach ($g in $hooked) { Log ('  - ' + $g.Title + '  (hook=' + $g.HookCount + ')') }
}

# ---------- 5. 启动 ----------
if ($DryRun) {
    Log '[DryRun] 结束（未修改、未启动）。'
    exit 0
}

if ($ConfigOnly) {
    # 只配置：重启 LT，不启动游戏
    Start-Process -FilePath $exe
    Log '已启动 LunaTranslator（仅配置模式，未启动游戏）。'
} else {
    $target = $null
    if ($GameUid) {
        $target = $hooked | Where-Object { $_.Uid -eq $GameUid } | Select-Object -First 1
        if (-not $target) { LogWarn ('指定的 GameUid 未找到或未保存 hook: ' + $GameUid) }
    }
    if (-not $target) { $target = $hooked | Select-Object -First 1 }

    if ($target) {
        # 关键：--Exec <uid> 让 LT 启动时自动打开该游戏并加载已保存的 hook
        Log ('启动游戏（自动 HOOK）: ' + $target.Title)
        Log ('  游戏路径: ' + $target.GamePath)
        Start-Process -FilePath $exe -ArgumentList @('--Exec', $target.Uid)
    } else {
        LogWarn '还没有"已选过文本行"的 galgame，无法全自动启动。'
        Log '首次需要做一次（约 10 秒，之后永久免做）:'
        Log '  1)  LunaTranslator 启动后，把游戏 exe 拖进它的窗口'
        Log '  2)  让游戏显示两三句对话，弹出"选择文本"窗口'
        Log '  3)  点一下和画面里对话完全一致的那一行（勾选"显示"列）'
        Log '  4)  关掉选择窗口，再运行本脚本 —— 以后就全自动了'
        Start-Process -FilePath $exe
    }
}

# ---------- 6. 验证端口 ----------
$ok = $false
for ($i = 0; $i -lt 15; $i++) {
    Start-Sleep -Seconds 1
    try {
        $r = Invoke-WebRequest -Uri 'http://127.0.0.1:2333/' -TimeoutSec 3 -UseBasicParsing
        if ($r.StatusCode -eq 200) { $ok = $true; break }
    } catch {}
}
if ($ok) {
    LogOk 'SUCCESS: 网络服务 127.0.0.1:2333 已就绪。'
    LogOk '现在回桌宠按 Ctrl+Alt+T，译文会显示在字幕浮层。'
} else {
    LogWarn '端口 2333 15 秒内未响应。请看 LunaTranslator 窗口是否有报错。'
}

if (-not $PSBoundParameters.ContainsKey('DryRun')) {
    Log '本窗口可关闭。'
}
