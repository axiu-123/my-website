@echo off
chcp 65001 >nul
title Galgame 一键翻译
set "PS1=%~dp0galgame-translate.ps1"
if not exist "%PS1%" (
  echo 错误：没有找到 galgame-translate.ps1
  echo 请确保本文件和 galgame-translate.ps1 放在同一个文件夹里。
  pause
  exit /b 1
)
echo.
echo ==========================================
echo   Galgame 一键翻译（自动 HOOK）
echo ==========================================
echo.
echo 提示：首次请把这两个文件放进 LunaTranslator 解压目录
echo       （和 LunaTranslator.exe 同一层），双击本文件即可。
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
echo.
echo 窗口将在 8 秒后自动关闭...
timeout /t 8 >nul
