@echo off
chcp 65001 >nul
set "PS1=%~dp0galgame-translate.ps1"
if not exist "%PS1%" goto NOPATH
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
goto END
:NOPATH
echo ERROR: galgame-translate.ps1 not found at %PS1%
:END
echo.
pause
