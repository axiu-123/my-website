@echo off
chcp 65001 >nul
title Galgame 一键翻译
set "PS1=%~dp0galgame-translate.ps1"
if not exist "%PS1%" (
  echo 错误：没有找到 galgame-translate.ps1
  echo 请把 galgame-translate.ps1、select-text-helper.ps1、换游戏.bat 一起放到 LunaTranslator 解压目录。
  pause
  exit /b 1
)
echo.
echo ==========================================
echo   Galgame 一键翻译（自动 HOOK）
echo ==========================================
echo.
echo 用法：把压缩包里全部文件放进 LunaTranslator 解压目录
echo       （和 LunaTranslator.exe 同一层），双击本文件即可。
echo       日常接着玩上次的游戏；首次玩会自动打开选文本助手。
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
echo.
echo 窗口将在 8 秒后自动关闭...
timeout /t 8 >nul
