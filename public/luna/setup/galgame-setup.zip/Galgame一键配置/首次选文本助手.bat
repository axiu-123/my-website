@echo off
chcp 65001 >nul
title 首次选文本助手
set "PS1=%~dp0select-text-helper.ps1"
if not exist "%PS1%" (
  echo 错误：没有找到 select-text-helper.ps1
  echo 请确保本文件和 select-text-helper.ps1 放在同一个文件夹里。
  pause
  exit /b 1
)
echo.
echo ==========================================
echo   首次选文本助手（只需用一次）
echo ==========================================
echo.
echo 用法：先让游戏显示一句对话，"选择文本"窗口弹出后，
echo       保持台词在画面上，再双击本文件。
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
pause
